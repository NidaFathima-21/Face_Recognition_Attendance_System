-- Create the database
CREATE DATABASE FaceRecognitionAttendanceSystem;

-- Use the database
USE FaceRecognitionAttendanceSystem;

-- Create a table to store user information
CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    roll_number VARCHAR(20) UNIQUE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create a table to store attendance records
CREATE TABLE Attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    attendance_time TIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    UNIQUE(user_id, attendance_date)
);

-- Create a table for user face data (store file paths or encoded representations)
CREATE TABLE FaceData (
    face_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    face_image_path VARCHAR(255) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

DELIMITER $$

CREATE PROCEDURE MarkAttendance (
    IN input_roll_number VARCHAR(20)
)
BEGIN
    DECLARE user_id INT;
    DECLARE attendance_exists INT;

    -- Get the user_id for the given roll number
    SELECT user_id INTO user_id
    FROM Users
    WHERE roll_number = input_roll_number;

    -- Check if attendance is already marked for today
    SELECT COUNT(*) INTO attendance_exists
    FROM Attendance
    WHERE user_id = user_id AND attendance_date = CURDATE();

    -- If attendance is not marked, insert a new record
    IF attendance_exists = 0 THEN
        INSERT INTO Attendance (user_id, attendance_date, attendance_time)
        VALUES (user_id, CURDATE(), CURTIME());
    END IF;
END$$

DELIMITER ;

--A trigger to delete related face data when a user is deleted:
DELIMITER $$

CREATE TRIGGER DeleteUserFaceData
AFTER DELETE ON Users
FOR EACH ROW
BEGIN
    DELETE FROM FaceData WHERE user_id = OLD.user_id;
END$$

DELIMITER ;

--A function to count the total number of registered users:
DELIMITER $$

CREATE FUNCTION TotalRegisteredUsers()
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE total_users INT;

    SELECT COUNT(*) INTO total_users FROM Users;

    RETURN total_users;
END$$

DELIMITER ;

--nested
SELECT username
FROM Users
WHERE user_id IN (
    SELECT user_id
    FROM Attendance
    WHERE attendance_date = CURDATE()
    AND user_id NOT IN (
        SELECT user_id
        FROM Attendance
        WHERE attendance_date BETWEEN DATE_SUB(CURDATE)
    )
);

--join 
SELECT 
    u.username,
    u.roll_number,
    a.attendance_date,
    a.attendance_time
FROM Attendance a
JOIN Users u ON a.user_id = u.user_id
ORDER BY a.attendance_date DESC, a.attendance_time DESC;


--Aggregate Query
SELECT 
    u.username,
    u.roll_number,
    COUNT(a.attendance_id) AS total_attendances
FROM Users u
LEFT JOIN Attendance a ON u.user_id = a.user_id
GROUP BY u.user_id
ORDER BY total_attendances DESC;
